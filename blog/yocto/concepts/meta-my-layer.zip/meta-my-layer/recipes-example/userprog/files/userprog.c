#include <stdio.h>

int main()
{
    printf("Hello World from\n");
    printf("meta-my-layer/recipes-example/userprog\n");
    return 0;
}
