#include <stdio.h>

int main()
{
    #ifdef USE_SYSCALL
        write(1, "USE_SYSCALL\n", 12);
        write(1, "Hello World from\n", 17);
        write(1, "meta-my-layer/recipes-example/userprog2\n", 40);
    #else
        printf("Hello World from\n");
        printf("meta-my-layer/recipes-example/userprog2\n");
    #endif
    return 0;
}
