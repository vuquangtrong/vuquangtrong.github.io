#!/bin/bash
# vuquangtrong.github.io

sudo python3 Picamera_MJPG_Server.py
