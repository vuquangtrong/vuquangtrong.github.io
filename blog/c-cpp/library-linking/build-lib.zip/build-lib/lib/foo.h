void setFoo(int f);
int getFoo();
