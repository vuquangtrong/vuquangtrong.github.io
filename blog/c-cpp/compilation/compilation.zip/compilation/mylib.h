// declaration
int min(int a, int b);
