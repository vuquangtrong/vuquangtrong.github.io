#include "SEGGER_RTT.h"

#if SEGGER_REDIRECTION

int _read(int file, char *ptr, int len) {
  *ptr = SEGGER_RTT_WaitKey();
  return 1;
}

int _write(int file, char *ptr, int len) {
  SEGGER_RTT_Write(0, ptr, len);
  return len;
}

#endif
