gcc hello_userspace.c -o hello_userspace
strace ./hello_userspace
echo "----------"

gcc hello_syscall_glibc.c -o hello_syscall_glibc
strace ./hello_syscall_glibc
echo "----------"

gcc hello_syscall_asm.s -nostdlib -no-pie -o hello_syscall_asm
strace ./hello_syscall_asm
