#include <stdio.h>

void main() {
    printf("USER: Hello World!\n");
}

